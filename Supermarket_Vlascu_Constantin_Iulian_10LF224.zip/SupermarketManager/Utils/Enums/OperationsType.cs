﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupermarketManager.Utils
{
    public enum OperationsType
    {
        None,
        Insert,
        Update,
        Delete
    }
}
