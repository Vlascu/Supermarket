CREATE TABLE Markups (
    MarkupID INT IDENTITY(1,1) PRIMARY KEY,
    MarkupPercentage INT,
    MarkupCategory INT
);